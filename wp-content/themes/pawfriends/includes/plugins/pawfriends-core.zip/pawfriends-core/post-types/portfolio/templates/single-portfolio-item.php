<?php

get_header();

pawfriends_mikado_get_title();

do_action('pawfriends_mikado_action_before_main_content');

pawfriends_core_get_single_portfolio();

get_footer();