<?php

include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/clients-grid/functions.php';
include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/clients-grid/clients-grid.php';