<?php

include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/button/functions.php';
include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/button/button.php';