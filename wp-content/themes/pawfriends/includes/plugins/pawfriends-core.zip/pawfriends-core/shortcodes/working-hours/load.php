<?php

include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/working-hours/functions.php';
include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/working-hours/working-hours.php';