<?php

include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/underline-text/functions.php';
include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/underline-text/underline-text.php';