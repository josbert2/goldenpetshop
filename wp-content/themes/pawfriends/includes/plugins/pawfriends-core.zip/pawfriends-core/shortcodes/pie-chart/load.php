<?php

include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/pie-chart/functions.php';
include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/pie-chart/pie-chart.php';