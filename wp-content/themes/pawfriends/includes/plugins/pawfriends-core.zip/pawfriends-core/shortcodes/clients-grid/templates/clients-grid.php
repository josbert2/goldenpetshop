<div class="mkdf-clients-grid-holder mkdf-grid-list mkdf-disable-bottom-space <?php echo esc_attr( $holder_classes ); ?>">
	<div class="mkdf-cg-inner mkdf-outer-space">
		<?php echo do_shortcode( $content ); ?>
	</div>
</div>