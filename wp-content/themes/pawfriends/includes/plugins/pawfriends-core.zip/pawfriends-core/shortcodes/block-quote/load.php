<?php

include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/block-quote/functions.php';
include_once PAWFRIENDS_CORE_SHORTCODES_PATH . '/block-quote/block-quote.php';